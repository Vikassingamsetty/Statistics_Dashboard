//
//  OpenInAir_AnalyticsApp.swift
//  OpenInAir_Analytics
//
//  Created by Vikas on 30/04/24.
//

import SwiftUI

@main
struct OpenInAir_AnalyticsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
