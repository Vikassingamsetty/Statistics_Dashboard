//
//  ContentView.swift
//  OpenInAir_Analytics
//
//  Created by Vikas on 30/04/24.
//

import SwiftUI

struct ContentView: View {
    
    @StateObject private var viewModel = AnalyticsViewModel()
    
    var body: some View {
        getInitialView()
            .onAppear {
                fetchDashboardInfo()
            }
            .alert(viewModel.errorMessage, isPresented: $viewModel.showAlert) { }
    }
    
    /// - NOTE: This will
    @ViewBuilder
    private func getInitialView() -> some View {
        switch viewModel.loadState {
        case .none:
            EmptyView()
        case .loading:
            ProgressView()
        case .fetched:
            contentView
        }
    }
    
    private var contentView: some View {
        VStack(spacing: 0) {
            VStack(spacing: 0) {
                DashBoardHeaderView()
                MainDashBoardView(model: viewModel.model) {
                    viewModel.openWhatsapp()
                }
            }
            .ignoresSafeArea(.all, edges: .top)
            .padding(.bottom, -35)
            TabBarView()
        }
    }
    
    /// - NOTE: Fetching the response
    private func fetchDashboardInfo() {
        Task {
            await viewModel.fetchDashboardDetails()
        }
    }
}

#Preview {
    ContentView()
}
