//
//  APILayer.swift
//  OpenInAir_Analytics
//
//  Created by Vikas on 30/04/24.
//

import Foundation
import SwiftUI

enum APIError: Error, LocalizedError {
    case urlNotFound
    case invalidHTTPResponse
    case unAuthorized
    case responseNotFound
    case invalidResponse
    
    var errorDescription: String? {
        switch self {
        case .urlNotFound:
            return "URL Not Found"
        case .invalidHTTPResponse:
            return "Invalid HTTP response"
        case .unAuthorized:
            return "UnAuthorized"
        case .responseNotFound:
            return "Response Not Found"
        case .invalidResponse:
            return "Invalid Response"
        }
    }
}

class APILayer {
    
    static let shared = APILayer()
    
    func fetchDashboardDetails() async throws -> AnalyticsModel {
        
        guard let url = URL(string: AppConstants.url) else {
            throw APIError.urlNotFound
        }
        
        var request = URLRequest(url: url)
        request.addValue("Bearer \(AppConstants.token)", forHTTPHeaderField: "Authorization")
        
        let (data, response) = try await URLSession.shared.data(for: request)
        guard let httpResponse = response as? HTTPURLResponse else {
            throw APIError.invalidHTTPResponse
        }
        
        switch httpResponse.statusCode {
        case 200...299:
             return try JSONDecoder().decode(AnalyticsModel.self, from: data)
        case 401:
            throw APIError.unAuthorized
        case 404:
            throw APIError.responseNotFound
        default:
            throw APIError.invalidResponse
        }
    }
}
