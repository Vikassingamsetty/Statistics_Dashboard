//
//  AnalyticsViewModel.swift
//  OpenInAir_Analytics
//
//  Created by Vikas on 02/05/24.
//

import Foundation
import UIKit

enum LoadState {
    
    case none
    case loading
    case fetched
}

enum Links: CaseIterable, Hashable {
    case topLinks
    case recentLinks
    
    var title: String {
        switch self {
        case .topLinks:
            return "Top Links"
        case .recentLinks:
            return "Recent Links"
        }
    }
    
    var isSelected: Links {
        switch self {
        case .topLinks:
            return .topLinks
        case .recentLinks:
            return .recentLinks
        }
    }
}

class AnalyticsViewModel: ObservableObject {
    
    @Published var model: AnalyticsModel?
    @Published var showAlert: Bool = false
    @Published var errorMessage: String = ""
    @Published var loadState: LoadState = .none
    
    /// - NOTE: Adopted MainActor for updating UI on main thread
    /// After fething the data from API
    @MainActor
    func fetchDashboardDetails() async {
        do {
            loadState = .loading
            model = try await APILayer.shared.fetchDashboardDetails()
            loadState = .fetched
        } catch {
            debugPrint(error.localizedDescription)
            showAlert = true
            errorMessage = error.localizedDescription
        }
    }
    
    private func createWhatsappURL(phoneNumber: String) -> URL {
        return URL(string: "https://api.whatsapp.com/send?phone=\(phoneNumber)")!
    }
    
    private func createWebWhatsappURL(phoneNumber: String) -> URL {
        return URL(string: "https://wa.me/\(phoneNumber)")!
    }
    
    private func openURL(_ url: URL) {
        if #available(iOS 10.0, *) {
            UIApplication.shared.open(url, options: [:], completionHandler: nil)
        } else {
            UIApplication.shared.openURL(url)
        }
    }
    
    func openWhatsapp() {
        guard let phoneNumber = model?.supportWhatsappNumber else { return }
        let appURL = createWhatsappURL(phoneNumber: phoneNumber)
        let webURL = createWebWhatsappURL(phoneNumber: phoneNumber)
        
        if UIApplication.shared.canOpenURL(appURL) {
            openURL(appURL)
        } else {
            openURL(webURL)
        }
    }
}
