//
//  AppConstants.swift
//  OpenInAir_Analytics
//
//  Created by Vikas on 30/04/24.
//

import Foundation
import SwiftUI

struct AppConstants {
    
    static let url = "https://api.inopenapp.com/api/v1/dashboardNew"
    static let token = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6MjU5MjcsImlhdCI6MTY3NDU1MDQ1MH0.dCkW0ox8tbjJA2GgUx2UEwNlbTZ7Rr38PVFJevYcXFI"
}

struct AppResources {
    
    // MARK: - Figtree Fonts
    static let bold = "Figtree-Bold"
    static let light = "Figtree-Light"
    static let medium = "Figtree-Medium"
    static let regular = "Figtree-Regular"
    static let semiBold = "Figtree-SemiBold"
    
    // MARK: - Icons
    static let settingsIcon = Image("settingsIcon")
    static let handIcon = Image("handWave")
    static let clickIcon = Image("click")
    static let globeIcon = Image("globe")
    static let locationIcon = Image("location")
    static let analyticsIcon = Image("analytics")
    static let allLinksIcon = Image("allLinks")
    static let questionIcon = Image("Info")
    static let whatsAppIcon = Image("whatsApp")
    static let searchIcon = Image("search")
    static let copyIcon = Image("copy")
    static let placeholderIcon = Image("broken-image")
    static let timeIcon = Image("Time")
    static let linksIcon = Image("Links")
    static let coursesIcon = Image("cources")
    static let campainIcon = Image("campain")
    static let profileIcon = Image("profile")
    
    // MARK: - Colors
    static let backgroundColor = Color(hex: "#0E6FFF")
    static let dashboardBgColor = Color(hex: "#F5F5F5")
    static let curvedBgColor = Color(uiColor: UIColor(red: 0.054901961237192154, green: 0.43529412150382996, blue: 1, alpha: 1))
    static let appTitleColor = Color(hex: "#999CA0")
    static let whatsAppBGColor = Color(hex: "#4AD15F")
    static let dottedEdgeColor = Color(hex: "#A6C7FF")
}
