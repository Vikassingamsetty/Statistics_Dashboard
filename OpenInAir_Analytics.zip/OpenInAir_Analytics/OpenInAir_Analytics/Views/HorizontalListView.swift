//
//  HorizontalListView.swift
//  OpenInAir_Analytics
//
//  Created by Vikas on 02/05/24.
//

import SwiftUI

struct HorizontalListView: View {
    
    private let cardItems: [CardItem] = [
        .init(image: "click", title: "123", subTitle: "Today's clicks"),
        .init(image: "location", title: "Ahamedabad", subTitle: "Top Location"),
        .init(image: "globe", title: "Instagram", subTitle: "Top Source"),
        .init(image: "globe", title: "11:00 - 12:00", subTitle: "Best Time")
    ]
    
    var body: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 16) {
                ForEach(cardItems, id: \.self) { card in
                    ZStack {
                        VStack(alignment: .leading, spacing: 15){
                            Image(card.image, bundle: .main)
                                .resizable()
                                .frame(width: 32, height: 32)
                            VStack(alignment: .leading, spacing: 6) {
                                Text(card.title)
                                    .lineLimit(1)
                                    .foregroundStyle(.black)
                                    .font(.custom(AppResources.medium, size: 14))
                                Text(card.subTitle)
                                    .foregroundStyle(AppResources.appTitleColor)
                                    .font(.custom(AppResources.regular, size: 13))
                            }
                        }
                        .padding(.horizontal, 15)
                    }
                    .frame(width: 120, height: 120, alignment: .leading)
                    .background(Color.white)
                    .cornerRadius(8)
                    .shadow(color: .gray.opacity(0.2), radius: 1)
                }
            }
            .padding()
        }
    }
}

#Preview {
    HorizontalListView()
}
