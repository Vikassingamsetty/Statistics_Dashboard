//
//  MainDashboardView+Ext.swift
//  OpenInAir_Analytics
//
//  Created by Vikas on 02/05/24.
//

import Foundation
import SwiftUI
import Charts

extension MainDashBoardView {
    
    func chartView() -> some View {
        ZStack {
            RoundedRectangle(cornerRadius: 8)
                .fill(.white)
                .shadow(color: .gray.opacity(0.2), radius: 1)
            
            VStack(spacing: 10) {
                chartHeaderView()
                lineChartView()
            }
            .padding(.all, 20)
            
        }
        .frame(height: 200)
        .frame(maxWidth: .infinity)
        .padding(.horizontal, 20)
    }
    
    @ViewBuilder
    func lineChartView() -> some View {
        let linearGradient = LinearGradient(colors: [AppResources.backgroundColor.opacity(0.7), AppResources.backgroundColor.opacity(0)], startPoint: .top, endPoint: .bottom)
        
        let analytics = model?.data.overallURLChart ?? ["00:00": 0]
        let keys = analytics.sorted(by: { $0.key < $1.key})
        
        Chart(keys, id: \.key) { key, value in
            let component = key.components(separatedBy: ":")
            
            LineMark(
                x: .value("Hour", component[0]),
                y: .value("Views", value)
            )
            .foregroundStyle(AppResources.backgroundColor)
            
            AreaMark(
                x: .value("Hour", component[0]),
                y: .value("Views", value)
            )
            .foregroundStyle(linearGradient)
        }
        .chartYAxis {
            AxisMarks(position: .leading)
        }
    }
    
    func chartHeaderView() -> some View {
        
        HStack(alignment: .center) {
            Text("Overview")
                .foregroundStyle(AppResources.appTitleColor)
                .font(.custom(AppResources.regular, size: 14))
            Spacer()
            HStack {
                Text("22 Aug - 23 Sept")
                    .foregroundStyle(.black)
                    .font(.custom(AppResources.regular, size: 14))
                
                AppResources.timeIcon
                    .resizable()
                    .frame(width: 20, height: 20)
            }
            .frame(height: 28)
            .padding(.all, 5)
            .overlay(
                RoundedRectangle(cornerRadius: 8, style: .circular)
                    .stroke(AppResources.appTitleColor.opacity(0.5), lineWidth: 1)
            )
        }
    }
    
    @ViewBuilder
     func segmentedListView() -> some View {
        
        let data = selectedLink == .topLinks ? model?.data.topLinks : model?.data.recentLinks
        
        if let linksData = data, !linksData.isEmpty {
            let firstFiveLinks = linksData.prefix(5) // Get the first 5 elements
            
            VStack(spacing: 25) {
                ForEach(firstFiveLinks, id: \.urlId) { link in
                    LinksListView(image: link.originalImage, title: link.title, postedDate: link.createdAt, webURL: link.webLink, totalClicks: link.totalClicks)
                        .frame(height: 113)
                }
            }
            .padding(.horizontal, 20)
        }
    }
    
     func communicationView() -> some View {
        
        VStack(spacing: 15) {
            CustomFeedbackButton(title: "Talk with us", image: AppResources.whatsAppIcon, color: AppResources.whatsAppBGColor) {
                didTapOnWhatApp()
                debugPrint("Navigate to whatsapp")
            }
            
            CustomFeedbackButton(title: "Frequently Asked Questions", image: AppResources.questionIcon, color: AppResources.backgroundColor) {
                debugPrint("Navigate to Frequently Asked Questions")
            }
        }
    }
    
     func segementedView() -> some View {
        HStack(spacing: 10) {
            ForEach(Links.allCases, id: \.title) { link in
                CapsuleButton(title: link.title, isSelected: selectedLink == link) {
                    withAnimation {
                        selectedLink = link.isSelected
                    }
                }
            }
            Spacer()
            Button(action: {
                debugPrint("navigate to search view")
            }) {
                AppResources.searchIcon
                    .resizable()
                    .frame(width: 36, height: 36)
            }
        }
        .frame(height: 50)
        .padding(.bottom, 10)
        .padding(.horizontal, 20)
    }
    
     func roundedRectangularBGView() -> some View {
        AppResources.dashboardBgColor
            .cornerRadius(16, corners: [.topLeft, .topRight])
    }
    
     func greetingsView() -> some View {
        /// - NOTE: Fetching current time and showing the Greetings
        VStack(alignment: .leading, spacing: 6) {
            Text(Dates.getCurrentTimeGreetings())
                .foregroundStyle(AppResources.appTitleColor)
                .font(.custom(AppResources.medium, size: 16))
            
            HStack {
                Text("Vikas")
                    .foregroundStyle(.black)
                    .font(.custom(AppResources.bold, size: 24))
                
                AppResources.handIcon
                    .resizable()
                    .aspectRatio(contentMode: .fill)
                    .frame(width: 28, height: 28)
                    .clipped()
                    .rotationEffect(.degrees(angle))
                    .onAppear {
                        withAnimation(.easeInOut(duration: 0.5).repeatForever(autoreverses: true)) {
                            angle = 15
                        }
                    }
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(.top, 30)
        .padding(.horizontal, 20)
    }
}
