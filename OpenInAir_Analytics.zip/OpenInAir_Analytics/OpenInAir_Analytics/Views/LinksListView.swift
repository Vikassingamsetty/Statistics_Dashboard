//
//  LinksListView.swift
//  OpenInAir_Analytics
//
//  Created by Vikas on 02/05/24.
//

import SwiftUI

struct LinksListView: View {
    
    let image: String
    let title: String
    let postedDate: String
    let webURL: String
    let totalClicks: Int
    
    var body: some View {
        VStack(spacing: 0) {
            HStack {
                /// Fetching Image
                asyncImage
                
                // Title & posted date
                VStack(alignment: .leading, spacing: 8) {
                    Text(title)
                        .lineLimit(1)
                        .font(.custom(AppResources.regular, size: 14))
                    Text(Dates.formatDate(postedDate))
                        .font(.custom(AppResources.regular, size: 12))
                        .foregroundColor(AppResources.appTitleColor)
                }
                
                Spacer()
                
                // Total clicks and title
                VStack(alignment: .leading, spacing: 8){
                    Text(String(totalClicks))
                        .font(.custom(AppResources.bold, size: 14))
                        .foregroundColor(.black)
                    Text("Clicks")
                        .font(.custom(AppResources.regular, size: 12))
                        .foregroundStyle(AppResources.appTitleColor)
                }
            }
            .frame(maxWidth: .infinity)
            .padding(.all, 15)
            .background(Color.white)
            
            /// - NOTE: Dotted background with URL which enable to copy URL to clipboard
            copyToClipboard
        }
        .cornerRadius(8, corners: [.allCorners])
    }
    
    /// - NOTE: On success - will show the image
    /// on Failure - Placeholder is shown
    /// on Empty - ProgressView to load data
    private var asyncImage: some View {
        AsyncImage(url: URL(string: image)) { phase in
            switch phase {
            case .empty: ProgressView()
            case .success(let image): image.resizable()
            case .failure: AppResources.placeholderIcon.resizable()
            default: EmptyView()
            }
        }
        .aspectRatio(contentMode: .fill)
        .frame(width: 48, height: 48)
        .cornerRadius(8)
    }
    
    private var copyToClipboard: some View {
        ZStack(alignment: .leading) {
            HStack {
                Text(webURL)
                    .foregroundStyle(AppResources.backgroundColor.opacity(1))
                    .font(.custom(AppResources.regular, size: 12))
                    .lineLimit(1)
                Spacer()
                Button {
                    UIPasteboard.general.string = webURL
                    debugPrint("Copied to clipboard")
                } label: {
                    AppResources.copyIcon
                }
            }
            .padding(.horizontal, 15)
            
            Rectangle()
                .strokeBorder(style: StrokeStyle(lineWidth: 1.5, dash: [3]))
                .foregroundStyle(AppResources.dottedEdgeColor)
        }
        .frame(height: 40)
        .frame(maxWidth: .infinity)
        .background(AppResources.dottedEdgeColor.opacity(0.2))
    }
}
