//
//  DashBoardHeaderView.swift
//  OpenInAir_Analytics
//
//  Created by Vikas on 02/05/24.
//

import SwiftUI

struct DashBoardHeaderView: View {
    
    var body: some View {
        
        ZStack(alignment: .bottom) {
            AppResources.backgroundColor
                .frame(height: 130)
            HStack {
                Text("Dashboard")
                    .foregroundStyle(.white)
                    .font(.custom(AppResources.bold, size: 24))
                Spacer()
                AppResources.settingsIcon
                    .resizable()
                    .frame(width: 20, height: 20, alignment: .center)
                    .background {
                        RoundedRectangle(cornerRadius: 10)
                            .foregroundStyle(.white.opacity(0.2))
                            .frame(width: 40, height: 40, alignment: .center)
                    }
                    .padding(.trailing, 10)
            }
            .padding(.horizontal, 15)
            .padding(.bottom, 30)
        }
    }
}

#Preview {
    DashBoardHeaderView()
}
