//
//  TabBarView.swift
//  OpenInAir_Analytics
//
//  Created by Vikas on 02/05/24.
//

import SwiftUI

struct TabBarView: View {
    
    @State private var index = 0
    
    var body: some View {
        VStack {
            TabView(index: $index)
        }
    }
}

struct TabView: View {
    
    @Binding var index: Int
    
    var body: some View {
        
        HStack {
            Button {
                index = 0
            } label: {
                VStack {
                    AppResources.linksIcon
                        .renderingMode(.template)
                        .resizable()
                        .frame(width: 32, height: 32)
                    Text("Links")
                        .font(.system(size: 12))
                }
            }
            .foregroundStyle(Color.black.opacity(index == 0 ? 1 : 0.2))
            
            Spacer()
            
            Button {
                index = 1
            } label: {
                VStack {
                    AppResources.coursesIcon
                        .renderingMode(.template)
                        .resizable()
                        .frame(width: 32, height: 32)
                    Text("Courses")
                        .font(.system(size: 12))
                }
            }
            .foregroundStyle(Color.black.opacity(index == 1 ? 1 : 0.2))
            
            Spacer()
            
            Button(action: {
                index = 2
            }) {
                Image(systemName: "plus")
                    .foregroundColor(.white)
                    .padding(.all, 20)
            }
            .background(Color.blue.gradient)
            .clipShape(.circle)
            .offset(y: -25)
            
            Spacer()
            
            Button {
                index = 3
            } label: {
                VStack {
                    AppResources.campainIcon
                        .renderingMode(.template)
                        .resizable()
                        .frame(width: 32, height: 32)
                    Text("Campaigns")
                        .font(.custom(AppResources.medium, size: 10))
                }
            }
            .foregroundStyle(Color.black.opacity(index == 3 ? 1 : 0.2))
            
            Spacer()
            
            Button {
                index = 4
            } label: {
                VStack {
                    AppResources.profileIcon
                        .renderingMode(.template)
                        .resizable()
                        .frame(width: 32, height: 32)
                    Text("Profile")
                        .font(.custom(AppResources.medium, size: 11))
                }
            }
            .foregroundStyle(Color.black.opacity(index == 4 ? 1 : 0.2))
        }
        .padding(.horizontal, 35)
        .padding(.top, 35)
        .background(Color.white)
        .clipShape(CShape())
    }
}

struct CShape: Shape {
    
    func path(in rect: CGRect) -> Path {
        return Path{ path in
            
            path.move(to: CGPoint(x: 0, y: 35))
            path.addLines(
                [
                    CGPoint(x: 0, y: 35),
                    CGPoint(x: 0, y: rect.height),
                    CGPoint(x: rect.width, y: rect.height),
                    CGPoint(x: rect.width, y: 35)
                ]
            )
            path.addArc(
                center: CGPoint(x: (rect.width / 2), y: 35),
                radius: 35,
                startAngle: .zero,
                endAngle: .init(degrees: 180),
                clockwise: true
            )
        }
    }
}

#Preview {
    TabBarView()
}
