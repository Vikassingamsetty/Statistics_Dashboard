//
//  CustomLinksButton.swift
//  OpenInAir_Analytics
//
//  Created by Vikas on 02/05/24.
//

import SwiftUI

struct CustomLinksButton: View {
    
    var title: String
    var image: Image
    var didTap: () -> Void
    
    var body: some View {
        Button {
            didTap()
        } label: {
            HStack(alignment: .center) {
                image
                    .font(.title)
                Text(title)
                    .foregroundStyle(.black)
                    .font(.custom(AppResources.semiBold, size: 16))
            }
            .frame(height: 48)
            .frame(maxWidth: .infinity)
        }
        .overlay(
            RoundedRectangle(cornerRadius: 8, style: .circular)
                .stroke(Color.gray.opacity(0.2), lineWidth: 1)
                .shadow(color: .gray.opacity(0.2), radius: 0.5)
        )
        .padding(.horizontal, 20)
    }
}

struct CustomFeedbackButton: View {
    
    var title: String
    var image: Image
    var color: Color
    var didTap: () -> Void
    
    var body: some View {
        Button {
            didTap()
        } label: {
            HStack(alignment: .center, spacing: 15) {
                image
                    .font(.title)
                Text(title)
                    .foregroundStyle(.black)
                    .font(.custom(AppResources.bold, size: 16))
            }
            .padding(.leading, 15)
            .frame(height: 65)
            .frame(maxWidth: .infinity, alignment: .leading)
        }
        .background(color.opacity(0.1))
        .overlay(
            RoundedRectangle(cornerRadius: 8, style: .circular)
                .stroke(color.opacity(0.4), lineWidth: 1)
                .shadow(color: color.opacity(0.1), radius: 0.5)
        )
        .padding(.horizontal, 20)
        
    }
}

struct CapsuleButton: View {
    
    var title: String
    var isSelected: Bool
    var didTap: () -> Void
    
    var body: some View {
        Button(action: {
            didTap()
        }) {
            Text(title)
                .font(.custom(AppResources.bold, size: 16))
                .foregroundColor(isSelected ? .white : AppResources.appTitleColor)
        }
        .frame(height: 36)
        .padding(.horizontal)
        .background(isSelected ? AppResources.backgroundColor : Color.clear)
        .clipShape(.capsule)
    }
}

#Preview {
    CustomLinksButton(title: "Analytics", image: AppResources.analyticsIcon) { }
}
