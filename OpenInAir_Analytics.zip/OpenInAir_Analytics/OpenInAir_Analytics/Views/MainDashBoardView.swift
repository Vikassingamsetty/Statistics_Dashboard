//
//  MainDashBoardView.swift
//  OpenInAir_Analytics
//
//  Created by Vikas on 02/05/24.
//

import SwiftUI

struct MainDashBoardView: View {
    
    @State var angle: Double = 0.0
    @State var selectedLink: Links = .topLinks
    let model: AnalyticsModel?
    let didTapOnWhatApp: () -> Void
    
    var body: some View {
        
        ZStack{
            roundedRectangularBGView()
            
            ScrollView(.vertical) {
                /// - NOTE: Greetings with username
                greetingsView()
                
                /// - NOTE: Chart View
                chartView()
                
                /// - NOTE: Horizontal list view
                HorizontalListView()
                
                /// - NOTE: Analytics
                CustomLinksButton(title: "View Analytics", image: AppResources.analyticsIcon) {
                    debugPrint("Navigate to analytics")
                }.padding(.bottom, 25)
                
                /// - NOTE: Segmented header view
                segementedView()
                
                /// - NOTE: listview for the selected segment
                segmentedListView()
                
                /// - NOTE: View All Links
                CustomLinksButton(title: "View all Links", image: AppResources.allLinksIcon) {
                    debugPrint("Navigate to All Links")
                }
                .padding(.top, 10)
                .padding(.bottom, 30)
                
                /// - NOTE: Communication Views
                communicationView()
                Spacer()
            }
            .scrollIndicators(.hidden)
        }
        .background(AppResources.curvedBgColor)
        .edgesIgnoringSafeArea([.top, .bottom])
    }
}
